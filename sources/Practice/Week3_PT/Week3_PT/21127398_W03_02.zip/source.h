#include <iostream>

using namespace std;


void addOne(int*);
int doSomething(int*, int*);