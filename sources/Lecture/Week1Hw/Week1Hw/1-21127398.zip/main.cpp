#include "Source.h"
int main() {
    Plantation p;
    p = ReadFile();
    WriteFile(p);


}