#pragma once

#include <iostream>

using namespace std;

int calA(int);
int calB(int,int);
float calC(int);
void printPascalTriangle(int);

int sumEven(int[],int);
int findMax(int[],int,int);
void reverseString(char[],int);
void printCurrency(int);


void printPermutation(char*,int, int);
char* toString(int n);
void swapchar(char&,char&);
void printKpermutation(char*,int ,int,int);
void printKsets(char*,int,int,int);