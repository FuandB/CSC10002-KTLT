#include "source.h"

int main(){
    
    
    int n;

    cout<< "enter n: ";cin>>n;

    //6.1
    cout<<calA(n)<<endl;
    int x = 3;
    cout<<calB(n,x)<<endl;
    cout<<calC(n);

    //6.2
    int arr[] = {1,2,3,4,5,6};
    int size = 6;
    cout<<endl;
    cout<<sumEven(arr,size);
    cout<<endl;
    cout<<findMax(arr,size,0);
    cout<<endl;
    char string[] = {'a','b','c','d','e'};
    reverseString(string,4);
    cout<<endl;
    printCurrency(8023048);
    cout<<endl;

    char * a = toString(n);
    printPermutation(a,0,n-1);
    printKpermutation(a,0,n-1,3);

}